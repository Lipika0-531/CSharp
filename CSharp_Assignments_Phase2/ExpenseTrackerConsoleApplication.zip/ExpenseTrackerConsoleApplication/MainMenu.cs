﻿using ConsoleTables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ExpenseTrackerConsoleApplication
{
    /// <summary>
    /// Contains menu to be displayed.
    /// </summary>
    public class MainMenu
    {
        Parser parser;
        UserAuthentication userAuthentication;
        FileManager fileManager;
        Services services;
        public MainMenu()
        {
            parser = new Parser();
            userAuthentication = new UserAuthentication();
            fileManager = new FileManager();
            services = new Services();
        }

        /// <summary>
        /// Menu to be displayed.
        /// </summary>
        /// <returns>Task</returns>
        public async Task UserMenu()
        {
            try
            {

                string userData = string.Empty;
                User user = null;
                string userNameToSignUp = string.Empty;
                string passwordToSignUp = string.Empty;
                ActiveUsers.ActiveUser = string.Empty;

                while (true)
                {
                    parser.DisplayMessages(ConsoleColor.Cyan, "\nWelcome to Expense Tracker");
                    parser.DisplayMessages(ConsoleColor.Cyan, "1. SignUp");
                    parser.DisplayMessages(ConsoleColor.Cyan, "2. LogIn");
                    parser.DisplayMessages(ConsoleColor.Cyan, "3. Add Income");
                    parser.DisplayMessages(ConsoleColor.Cyan, "4. Add Expense");
                    parser.DisplayMessages(ConsoleColor.Cyan, "5. View Income");
                    parser.DisplayMessages(ConsoleColor.Cyan, "6. View Expense");
                    parser.DisplayMessages(ConsoleColor.Cyan, "7. Update Income");
                    parser.DisplayMessages(ConsoleColor.Cyan, "8. Update Expense");
                    parser.DisplayMessages(ConsoleColor.Cyan, "9. Delete Income");
                    parser.DisplayMessages(ConsoleColor.Cyan, "10. Delete Expense");
                    parser.DisplayMessages(ConsoleColor.Cyan, "11. View Statistics");
                    parser.DisplayMessages(ConsoleColor.Cyan, "12. LogOut");
                    parser.DisplayMessages(ConsoleColor.Cyan, "13. Exit");

                    Console.Write("Choose option : ");

                    if (Enum.TryParse(Console.ReadLine(), out MenuOptions option))
                    {
                        switch (option)
                        {
                            case MenuOptions.SignUp:
                                Console.WriteLine("SignUp");
                                userNameToSignUp = parser.ValidateInputs<string>(ConsoleColor.Yellow, "Enter UserName : ");
                                passwordToSignUp = parser.ValidateInputs<string>(ConsoleColor.Yellow, "Enter Password : ");
                                userNameToSignUp = userAuthentication.CheckIfUserNameUnique(userNameToSignUp);
                                user = userAuthentication.UserSignIn(userNameToSignUp, passwordToSignUp);
                                //fileManager.WriteSignInDetailsToFile(userNameToSignUp, passwordToSignUp, user);

                                Console.WriteLine($"Active Users : {ActiveUsers.ActiveUser}");
                                break;
                            case MenuOptions.LogIn:
                                Console.WriteLine("LogIn");
                                string userNameToLogin = parser.ValidateInputs<string>(ConsoleColor.Yellow, "Enter User Name : ");
                                string passwordToLogin = parser.ValidateInputs<string>(ConsoleColor.Yellow, "Enter Password : ");
                                User userLogin = new User(userNameToLogin, passwordToLogin);
                                await userAuthentication.LogIn(userNameToLogin, passwordToLogin, userLogin);
                                user = userLogin;

                                ActiveUsers.ActiveUser = user.UserName;


                                break;
                            case MenuOptions.AddIncome:
                                if (ActiveUsers.ActiveUser == user.UserName)
                                {
                                    parser.DisplayMessages(ConsoleColor.Yellow, "Add Income");
                                    Income incomeToAdd = services.GetIncomeInputs();
                                    user?.AddIncome(incomeToAdd);
                                }
                                else
                                {
                                    parser.DisplayMessages(ConsoleColor.Red, "Login or SignUp !");
                                }

                                break;
                            case MenuOptions.AddExpense:

                                if (ActiveUsers.ActiveUser == user.UserName)
                                {
                                    parser.DisplayMessages(ConsoleColor.Yellow, "Add Income");
                                    Expense expenseToAdd = services.GetExpenseInputs();
                                    user?.AddExpense(expenseToAdd);
                                }
                                else
                                {
                                    parser.DisplayMessages(ConsoleColor.Red, "Login or SignUp !");
                                }
                                break;
                            case MenuOptions.ViewIncomes:
                                if (ActiveUsers.ActiveUser == user.UserName)
                                {
                                    parser.DisplayMessages(ConsoleColor.Yellow, "View Income ");
                                    user?.ViewIncome(user);
                                }
                                else
                                {
                                    parser.DisplayMessages(ConsoleColor.Red, "Login or SignUp !");
                                }
                                break;
                            case MenuOptions.ViewExpenses:
                                if (ActiveUsers.ActiveUser == user.UserName)
                                {
                                    parser.DisplayMessages(ConsoleColor.Yellow, "View Expense ");
                                    user?.ViewExpense(user);
                                }
                                else
                                {
                                    parser.DisplayMessages(ConsoleColor.Red, "Login or SignUp !");
                                }

                                break;
                            case MenuOptions.UpdateIncomes:
                                if (ActiveUsers.ActiveUser == user.UserName)
                                {
                                    user.UpdatingValuesForUserIncome();
                                }
                                else
                                {
                                    parser.DisplayMessages(ConsoleColor.Red, "Login or SignUp !");
                                }
                                break;
                            case MenuOptions.UpdateExpenses:
                                if (ActiveUsers.ActiveUser == user.UserName)
                                {
                                    user.UpdatingValuesForUserExpense();
                                }
                                else
                                {
                                    parser.DisplayMessages(ConsoleColor.Red, "Login or SignUp !");
                                }
                                break;
                            case MenuOptions.RemoveIncome:
                                if (ActiveUsers.ActiveUser == user.UserName)
                                {
                                    user?.DeleteIncome(user);
                                }
                                else
                                {
                                    parser.DisplayMessages(ConsoleColor.Red, "Login or SignUp !");
                                }
                                break;
                            case MenuOptions.RemoveExpense:
                                if (ActiveUsers.ActiveUser == user.UserName)
                                {
                                    user?.DeleteExpense(user);
                                }
                                else
                                {
                                    parser.DisplayMessages(ConsoleColor.Red, "Login or SignUp !");
                                }
                                break;
                            case MenuOptions.ViewStatistic:
                                if (ActiveUsers.ActiveUser == user.UserName)
                                {
                                    user?.ViewTotalExpense(user);
                                    user?.ViewTotalIncome(user);
                                }
                                else
                                {
                                    parser.DisplayMessages(ConsoleColor.Red, "Login or SignUp !");
                                }
                                break;
                            case MenuOptions.LogOut:
                                if (ActiveUsers.ActiveUser == user.UserName)
                                {
                                    parser.DisplayMessages(ConsoleColor.Magenta, "Logging out !");

                                    await userAuthentication.LogOutUser(user);
                                    fileManager.WriteSignInDetailsToFile(user);

                                }
                                else
                                {
                                    parser.DisplayMessages(ConsoleColor.Red, "Login or SignUp !");
                                }
                                break;
                            case MenuOptions.Exit:
                                parser.DisplayMessages(ConsoleColor.Green, $"ThankYou {user.UserName}");
                                Environment.Exit(0);
                                break;
                            default:
                                parser.DisplayMessages(ConsoleColor.Red, "Invalid Input !");
                                break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                parser.DisplayMessages(ConsoleColor.Red,$"Error: {ex}");
            }
        }
    }
}
