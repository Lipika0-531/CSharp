﻿using ConsoleTables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ExpenseTrackerConsoleApplication
{
    /// <summary>
    /// Define user.
    /// </summary>
    public partial class User
    {
        Parser parser;
        Category category;
        public User()
        {
           
        }
        public User(string userName, string password)
        {
            UserName = userName;
            Password = new Password(password);
            Incomes = new List<Income>();
            Expenses = new List<Expense>();
            parser = new Parser();
            category = new Category();
        }

        /// <summary>
        /// Get UserName.
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// Get Password.
        /// </summary>
        public Password Password { get; set; }

        /// <summary>
        /// Get Incomes.
        /// </summary>
        public List<Income> Incomes { get; set; }

        /// <summary>
        /// Get Expenses.
        /// </summary>
        public List<Expense> Expenses { get; set; }

        /// <summary>
        /// Adding Income.
        /// </summary>
        /// <param name="income">Income</param>
        public void AddIncome(Income income)
        {
            Incomes.Add(income);
            parser.DisplayMessages(ConsoleColor.Green, "Income Successfully Added !");
        }

        /// <summary>
        /// Adding Expense.
        /// </summary>
        /// <param name="expense">Expense</param>
        public void AddExpense(Expense expense)
        {
            Expenses.Add(expense);
            parser.DisplayMessages(ConsoleColor.Green, "Expense Successfully Added !");
        }

        /// <summary>
        /// View Expense.
        /// </summary>
        /// <param name="user">User</param>
        public void ViewExpense(User user)
        {
            if (user.Expenses != null)
            {
                Console.WriteLine($"Expense Table : \nUserName : {user.UserName}");
                ConsoleTable viewExpenseTable = new ConsoleTable("Date", "Amount", "Mode of cash", "Category", "Account", "Notes");
                foreach (var value in this.Expenses)
                {
                    viewExpenseTable.AddRow(value.DateOnly.ToString(), value.Amount, value.AmountMode.ToString(), value.Category, value.Account, value.Note);
                }
                viewExpenseTable.Write();
            }
            else
            {
                parser.DisplayMessages(ConsoleColor.Red, "No expense Added !");
            }
        }

        public void ViewTotalExpense(User user)
        {
            double totalExpense = 0;
            if (user.Expenses != null && user.Expenses.Count > 0)
            {
                foreach (var value in this.Expenses)
                {
                    totalExpense += value.Amount;
                }

                Console.BackgroundColor = ConsoleColor.Cyan;
                parser.DisplayMessages(ConsoleColor.Magenta, $"Total expense: {totalExpense}");
                Console.BackgroundColor = ConsoleColor.White;

            }
            else
            {
                parser.DisplayMessages(ConsoleColor.Red, "No expense Added !");
            }
        }

        public void ViewTotalIncome(User user)
        {
            double totalIncome = 0;
            if (user.Incomes != null && user.Incomes.Count > 0)
            {
                foreach (var value in this.Incomes)
                {
                    totalIncome += value.Amount;
                }

                for(int i=0; i<totalIncome; i++)
                {
                    Console.BackgroundColor = ConsoleColor.Red;
                    Console.Write(" ");
                }
                Console.BackgroundColor = ConsoleColor.Black;
                parser.DisplayMessages(ConsoleColor.Magenta, $"Total Income: {totalIncome}");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else
            {
                parser.DisplayMessages(ConsoleColor.Red, "No Income Added !");
            }
        }

        /// <summary>
        /// View Income.
        /// </summary>
        /// <param name="user">User</param>
        public void ViewIncome(User user)
        {
            if (user.Incomes != null)
            {
                Console.WriteLine($"Income Table : \nUserName : {user.UserName}");
                ConsoleTable viewIncomeTable = new ConsoleTable("Date", "Amount", "Amount Mode ", "Category", "Account", "Notes");
                foreach (var value in user.Incomes)
                {
                    viewIncomeTable.AddRow(value.DateOnly.ToString(), value.Amount, value.AmountMode.ToString(), value.Category, value.Account, value.Note);
                }
                viewIncomeTable.Write();
            }
            else
            {
                parser.DisplayMessages(ConsoleColor.Red, "No expense Added !");
            }

        }

        Services services = new Services();

        /// <summary>
        /// Update Expense.
        /// </summary>
        public void UpdatingValuesForUserExpense()
        {
            try
            {

                int i = 1;
                int countTobeUpdated = 0;
                if (this.Expenses.Count > 0)
                {
                    ConsoleTable userMenuTableForUpdate = new("S.No", "Date", "Amount", " Amount Mode", "Category", " Account", " Notes");
                    foreach (var value in this.Expenses)
                    {
                        userMenuTableForUpdate.AddRow(i, value.DateOnly, value.Amount, value.AmountMode, value.Category, value.Account, value.Note);
                        i++;
                    }
                    userMenuTableForUpdate.Write();


                    countTobeUpdated = parser.ValidateInputs<int>(ConsoleColor.Yellow, "Choose which expense data to be updated :");
                }
                else
                {
                    parser.DisplayMessages(ConsoleColor.Red, "No Expenses ! Please add expense to update !");
                    return;
                }
                int choice = services.UpdateMenu();
                int accountNumberToUpdate = 0;
                if (choice <= 6)
                {
                    switch (choice)
                    {
                        case 1:
                            DateOnly updatedDate = DateOnly.Parse(parser.ValidateInputs<string>(ConsoleColor.Yellow, "Enter Date to be Updated : "));
                            this.Expenses[countTobeUpdated - 1].DateOnly = updatedDate;
                            parser.DisplayMessages(ConsoleColor.Yellow, $"Value Updated to {updatedDate}");
                            break;
                        case 2:
                            var updatedAmount = parser.ValidateInputs<double>(ConsoleColor.Yellow, "Enter Amount to be Updated : ");
                            this.Expenses[countTobeUpdated - 1].Amount = updatedAmount;
                            parser.DisplayMessages(ConsoleColor.Yellow, $"Value Updated to {updatedAmount}");
                            break;
                        case 3:
                            var amountModeToUpdate = parser.ValidateInputs<int>(ConsoleColor.Yellow, "Choose Mode of cash : 1. ECash \n2.Cash : ");
                            if (amountModeToUpdate == 1)
                            {
                                this.Expenses[countTobeUpdated - 1].AmountMode = ModesOfCash.ECash;
                                accountNumberToUpdate = parser.ValidateInputs<int>(ConsoleColor.Yellow, "Enter Account Number : ");
                                this.Expenses[countTobeUpdated - 1].Account = accountNumberToUpdate;
                            }
                            else
                            {
                                this.Expenses[countTobeUpdated - 1].AmountMode = ModesOfCash.Cash;
                            }
                            parser.DisplayMessages(ConsoleColor.Yellow, $"Value Updated to {amountModeToUpdate}");
                            break;
                        case 4:
                            var categoryToUpdate = services.GetCategory();
                            this.Expenses[countTobeUpdated - 1].Category = categoryToUpdate;
                            parser.DisplayMessages(ConsoleColor.Yellow, $"Value Updated to {categoryToUpdate}");
                            break;
                        case 5:
                            var updatedAccountNumber = parser.ValidateInputs<int>(ConsoleColor.Yellow, "Enter Account Number : ");
                            this.Expenses[countTobeUpdated - 1].Account = updatedAccountNumber;
                            parser.DisplayMessages(ConsoleColor.Yellow, $"Value Updated to {updatedAccountNumber}");
                            break;
                        case 6:
                            var updatedNotes = parser.ValidateInputs<string>(ConsoleColor.Yellow, "Enter Notes : ");
                            this.Expenses[countTobeUpdated - 1].Note = updatedNotes;
                            parser.DisplayMessages(ConsoleColor.Yellow, $"Value Updated to {updatedNotes}");
                            break;
                        default:
                            parser.DisplayMessages(ConsoleColor.Red, "Invalid Input !");
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                parser.DisplayMessages(ConsoleColor.Red, ex.Message);
            }
        }

        /// <summary>
        /// Update Income.
        /// </summary>
        public void UpdatingValuesForUserIncome()
        {
            try
            {
                int i = 1;
                int countTobeUpdated = 0;
                int accountNumberToUpdate = 0;

                if (this.Incomes.Count > 0)
                {
                    ConsoleTable userMenuTableForUpdate = new("S.No", "Date", "Amount", " Amount Mode", "Category", " Account", " Notes");
                    foreach (var value in this.Incomes)
                    {
                        userMenuTableForUpdate.AddRow(i, value.DateOnly, value.Amount, value.AmountMode, value.Category, value.Account, value.Note);
                        i++;
                    }
                    userMenuTableForUpdate.Write();


                    countTobeUpdated = parser.ValidateInputs<int>(ConsoleColor.Yellow, "Choose which Income data to be updated :");
                }
                else
                {
                    parser.DisplayMessages(ConsoleColor.Red, "No Incomes ! Please add Income to update !");
                    return;
                }
                int choice = services.UpdateMenu();
                if (choice <= 6)
                {
                    switch (choice)
                    {
                        case 1:
                            DateOnly updatedDate = DateOnly.Parse(parser.ValidateInputs<string>(ConsoleColor.Yellow, "Enter Date to be Updated : "));
                            this.Incomes[countTobeUpdated - 1].DateOnly = updatedDate;
                            parser.DisplayMessages(ConsoleColor.Yellow, $"Value Updated to {updatedDate}");
                            break;
                        case 2:
                            var updatedAmount = parser.ValidateInputs<double>(ConsoleColor.Yellow, "Enter Amount to be Updated : ");
                            this.Incomes[countTobeUpdated - 1].Amount = updatedAmount;
                            parser.DisplayMessages(ConsoleColor.Yellow, $"Value Updated to {updatedAmount}");
                            break;
                        case 3:
                            var accountModeToUpdate = parser.ValidateInputs<int>(ConsoleColor.Yellow, "Choose Mode of cash : 1. ECash \n2.Cash : ");
                            if (accountModeToUpdate == 1)
                            {
                                this.Incomes[countTobeUpdated - 1].AmountMode = ModesOfCash.ECash;
                                accountNumberToUpdate = parser.ValidateInputs<int>(ConsoleColor.Yellow, "Enter Account Number : ");
                                this.Expenses[countTobeUpdated - 1].Account = accountNumberToUpdate;
                            }
                            else
                            {
                                this.Incomes[countTobeUpdated - 1].AmountMode = ModesOfCash.Cash;
                            }
                            parser.DisplayMessages(ConsoleColor.Yellow, $"Value Updated to {accountModeToUpdate}");
                            break;
                        case 4:
                            var categoryToUpdate = services.GetCategory();
                            this.Incomes[countTobeUpdated - 1].Category = categoryToUpdate;
                            parser.DisplayMessages(ConsoleColor.Yellow, $"Value Updated to {categoryToUpdate}");
                            break;
                        case 5:
                            var updatedAccountNumber = parser.ValidateInputs<int>(ConsoleColor.Yellow, "Enter Account Number : ");
                            this.Incomes[countTobeUpdated - 1].Account = updatedAccountNumber;
                            parser.DisplayMessages(ConsoleColor.Yellow, $"Value Updated to {updatedAccountNumber}");
                            break;
                        case 6:
                            var updatedNotes = parser.ValidateInputs<string>(ConsoleColor.Yellow, "Enter Notes : ");
                            this.Incomes[countTobeUpdated - 1].Note = updatedNotes;
                            parser.DisplayMessages(ConsoleColor.Yellow, $"Value Updated to {updatedNotes}");
                            break;
                        default:
                            parser.DisplayMessages(ConsoleColor.Red, "Invalid Input !");
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                parser.DisplayMessages(ConsoleColor.Red, ex.Message);
            }
        }

        /// <summary>
        /// Delete Income.
        /// </summary>
        /// <param name="user">User</param>
        public void DeleteIncome(User user)
        {
            int i = 1;
            int countTobeUpdated = 0;
            if (this.Incomes.Count > 0)
            {
                ConsoleTable userMenuTableForDelete = new("S.No", "Date", "Amount", " Amount Mode", "Category", " Account", " Notes");
                foreach (var value in this.Incomes)
                {
                    userMenuTableForDelete.AddRow(i, value.DateOnly, value.Amount, value.AmountMode, value.Category, value.Account, value.Note);
                    i++;
                }
                userMenuTableForDelete.Write();

                countTobeUpdated = parser.ValidateInputs<int>(ConsoleColor.Yellow, "Choose which Income data to be Deleted :");

                Incomes.Remove(user.Incomes[countTobeUpdated - 1]);
                parser.DisplayMessages(ConsoleColor.Green, "Successfully Deleted !");
            }
            else
            {
                parser.DisplayMessages(ConsoleColor.Red, "No Incomes ! Please add Income to Delete !");
            }
        }

        /// <summary>
        /// Delete Expense.
        /// </summary>
        /// <param name="user">User</param>
        public void DeleteExpense(User user)
        {
            int i = 1;
            int countTobeUpdated = 0;
            if (this.Expenses.Count > 0)
            {
                ConsoleTable userMenuTableForDelete = new("S.No", "Date", "Amount", " Amount Mode", "Category", " Account", " Notes");
                foreach (var value in this.Expenses)
                {
                    userMenuTableForDelete.AddRow(i, value.DateOnly, value.Amount, value.AmountMode, value.Category, value.Account, value.Note);
                    i++;
                }
                userMenuTableForDelete.Write();

                countTobeUpdated = parser.ValidateInputs<int>(ConsoleColor.Yellow, "Choose which Expense data to be Deleted :");

                Expenses.Remove(user.Expenses[countTobeUpdated - 1]);
                parser.DisplayMessages(ConsoleColor.Green, "Successfully Deleted !");
            }
            else
            {
                parser.DisplayMessages(ConsoleColor.Red, "No Expenses ! Please add Expense to delete !");
            }
        }
    }
}
