﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExpenseTrackerConsoleApplication
{
    public class UserAuthentication
    {
        volatile int isLoggedIn = 0;
        Parser parser;
        FileManager fileManager;

        public UserAuthentication()
        {
            parser = new Parser();
            fileManager = new FileManager();
        }

        /// <summary>
        /// User logIn.
        /// </summary>
        /// <param name="userName">UserName</param>
        /// <param name="password">Password</param>
        /// <returns>Task</returns>
        public async Task LogIn(string userName, string password, User user)
        {

            if (fileManager.LogInDetailsToFile(userName, password, user))
            {
                int i = 0;
                await Task.Run(() =>
                {
                    while (i <= 3)
                    {
                        Console.Write(".");
                        Thread.Sleep(1000);
                        i++;
                    }

                    parser.DisplayMessages(ConsoleColor.Green, $"Successfully Logged in ! \n Welcome {userName}");
                    Thread.Sleep(100);
                });
            }
            else
            {
                parser.DisplayMessages(ConsoleColor.Red, "No User found ! \nTry Signing In or Try again! :)");
            }
        }

        /// <summary>
        /// User LogOut.
        /// </summary>
        /// <param name="userName">UserName</param>
        /// <param name="password">Password</param>
        /// <returns>Task</returns>
        public async Task LogOutUser(User user)
        {
            if (ActiveUsers.ActiveUser != null)
            {
                int i = 0;
                await Task.Run(() =>
                {
                    while (i <= 3)
                    {
                        Console.Write(".");
                        Thread.Sleep(1000);
                        i++;
                    }
                    ActiveUsers.ActiveUser = null;
                    parser.DisplayMessages(ConsoleColor.Green, $"Successfully Logged out ! \n ThankYou {user.UserName}");

                    Thread.Sleep(100);
                });
                Console.Write('\n');
            }
            else
            {
                parser.DisplayMessages(ConsoleColor.Red, "No User found !");
            }

            return;
        }

        /// <summary>
        /// users will have user list.
        /// </summary>
        public static Dictionary<string, User> users = new Dictionary<string, User>();

        /// <summary>
        /// Add user.
        /// </summary>
        /// <param name="userName">userName</param>
        /// <param name="password">Password</param>
        /// <returns>Added User</returns>
        public User UserSignIn(string userName, string password)
        {
            var addUser = new User(userName, password);
            ActiveUsers.ActiveUser = addUser.UserName;
            fileManager.WriteSignInDetailsToFile(addUser);
            users[userName] = addUser;
            return addUser;
        }

        /// <summary>
        /// Check userName is unique.
        /// </summary>
        /// <param name="userName">userName</param>
        /// <returns>string</returns>
        public string CheckIfUserNameUnique(string userName)
        {
            while (users.ContainsKey(userName))
            {
                userName = parser.ValidateInputs<string>(ConsoleColor.Yellow, "UserName already taken, Enter valid UserName : ");
            }
            return userName;
        }
    }
}
