﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Nodes;
using System.Threading.Tasks;

namespace ExpenseTrackerConsoleApplication
{
    /// <summary>
    /// Adding and Reading Files.
    /// </summary>
    public class FileManager
    {
        Parser parser;
        string commonAppData;
        public FileManager() 
        {
            parser = new Parser();
            commonAppData = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
        }

        public string fileName(User user)
        {
            string userDetailsFile = $"{user.UserName}.json";
            return userDetailsFile;
        }
        public bool LogInDetailsToFile(string userNameLogin, string loginPassword, User user)
        {
            string userDetailsFile = fileName(user);

            if (!File.Exists(Path.Combine(commonAppData, userDetailsFile)))
            {
                parser.DisplayMessages(ConsoleColor.Red, "User not found ! Try signing in or Try again !");
                return false;
            }
            else
            {
                string content = File.ReadAllText(Path.Combine(commonAppData, userDetailsFile), Encoding.UTF8);
                User userNew = JsonConvert.DeserializeObject<User>(content)!;
                user = userNew;
                Password password = new Password(loginPassword);

                if (user.UserName == userNameLogin && user.Password.EncodedPassword == password.EncodedPassword)
                {
                    return true;
                }
                else
                {
                    parser.DisplayMessages(ConsoleColor.Red, "UserName and Password doesn't Match !");
                    return false;
                }
            }
        }

        public bool WriteSignInDetailsToFile(User user)
        {
            string userDetailsFile = fileName(user);

            using (FileStream writer = File.Create(Path.Combine(commonAppData, userDetailsFile)))
            {
                using (StreamWriter sw = new StreamWriter(writer))
                {
                    var encodedPassword = user.Password.EncodedPassword;
                    string jsonUserData = JsonConvert.SerializeObject(user);
                    sw.Write(jsonUserData);
                }
            }
            return true;
        }


        /*public bool WriteAndReadSignUpAndLogInDetailsToFile(string userNameLogin, string loginPassword, User user, string matchWord)
        {
            string userDetailsFile = $"{user.UserName}.json";

            try
            {

                if (matchWord == "SignIn")
                {
                    using (FileStream writer = File.Create(Path.Combine(commonAppData, userDetailsFile)))
                    {
                        using (StreamWriter sw = new StreamWriter(writer))
                        {
                            var encodedPassword = user.Password.EncodedPassword;
                            string jsonUserData = JsonConvert.SerializeObject(user);
                            sw.Write(jsonUserData);
                        }
                    }
                    return true;
                }
                else if (matchWord == "LogIn")
                {
                    if (!File.Exists(Path.Combine(commonAppData, userDetailsFile)))
                    {
                        parser.DisplayMessages(ConsoleColor.Red, "User not found ! Try signing in or Try again !");
                    }
                    else
                    {
                        string content = File.ReadAllText(Path.Combine(commonAppData, userDetailsFile), Encoding.UTF8);
                        User userNew = JsonConvert.DeserializeObject<User>(content)!;
                        user = userNew;
                        Password password = new Password(loginPassword);

                        if (user.UserName == userNameLogin && user.Password.EncodedPassword == password.EncodedPassword)
                        {
                            Console.WriteLine("\n");
                        }
                    }
                    return true;
                }
                return false;
            }
            catch(Exception ex)
            {
                parser.DisplayMessages(ConsoleColor.Red, $"Exception Thrown {ex.Message}");
                return false;
            }
            

        }*/
    }
}
